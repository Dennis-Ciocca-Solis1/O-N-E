package com.alura.screenmatch.calculos;

public interface Clasificable {
    int getClasificacion();
}
